package com.mytech.postdelivery.exception;

public class EmptyException extends Exception{
    public EmptyException(String message) {
        super(message);
    }
}
