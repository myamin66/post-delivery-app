package com.mytech.postdelivery.exception;

public class DuplicateException extends Exception{
    public DuplicateException(String message) {
        super(message);
    }
}
