import React from "react";
import Header from "./components/Header";
import { Redirect, Switch, Route } from "react-router-dom";
import Home from "./components/Home";
import Footer from "./components/Footer";
import { DataProvider } from "./components/DataProvider";
import Login from "./components/Signin/Login";
import Register from "./components/Signin/Register";
import Error from "./components/Error";
import ProgressOrders from "./components/ProgressOrders";
import ProgressDeliveries from "./components/ProgressDeliveries";
import DeliverProduct from "./components/DeliverProduct";
import About from "./components/About";
import {useState} from 'react'
import OrderDetails from "./components/OrderDetail";
import DeliveryDetails from "./components/DeliveryDetail";
import OrderProduct from "./components/OrderProduct";
function App() {

  const [search, setSearch] = useState("");

  return (
    <DataProvider>
      <>
        <Switch>
          <Route exact path="/error404" component={Error} />
          <Route>

            <Header setSearch={setSearch} />
            <Switch>
              <Route exact path="/" component={Home} />
              <Route exact path="/orders/:id" component={OrderDetails} />
              <Route exact path="/deliveries/:id" component={DeliveryDetails} />
              <Route exact path="/login" component={Login} />
              <Route exact path="/register" component={Register} />
              <Route exact path="/about" component={About} />
              <Route exact path="/orders" component={ProgressOrders} />
              <Route exact path="/deliveries" component={ProgressDeliveries} />
              <Route exact path="/addDelivery" component={DeliverProduct} />
              <Route exact path="/addOrder" component={OrderProduct} />
              <Redirect to="/error404" />
            </Switch>
            <Footer />
          </Route>
        </Switch>
      </>
    </DataProvider>
  );
}

export default App;
