import React, {useState,useContext} from 'react';
import Input from '@mui/material/Input';
import Button from '@mui/material/Button';
import {styled} from '@mui/material/styles';
import FormControl from '@mui/material/FormControl';
import { Alert } from '@mui/material';
import TextField from '@mui/material/TextField';
import Dataservices from './Dataservices';
import { DataContext } from './DataProvider';


export default function DeliverProduct() {
    const value = useContext(DataContext)
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [values, setValues] = React.useState({
        productName: '',
        productDescription: '',
        toContactNumber: '',
        fromContactNumber: '',
        quantity: '',
        toAddress: '',
        fromAddress: '',
        userId: value.currentUser.id ,
        riderId: 1 ,
    });

    
    const handleChange = (event) => {
        setValues({...values,  [event.target.name]: event.target.value});
    };

    const styles = {

        largeIcon: {
            width: 30,
            height: 30,
            marginRight: 3
        },
        backgroundImage: {
            width: '500px',
            borderRadius: 0,
            backgroundColor: 'none'
        }

    };

    const handleSubmit = (event) => {
        event.preventDefault();
        Dataservices.createDelivery(values).then(res =>  setIsSubmitting(true))
    }
    
    const Input = styled('input')({
        display: 'none',
    });


    return (
        <section>
            <div className="landing-box"
                 style={{display: 'flex', flexDirection: 'row', justifyContent: 'space-around', textAlign: 'start'}}>
                <div>
                    <h1>Deliver Product</h1>
                    <p>Add some information for the product you want to deliver.</p>
                    <br/>
                    { (isSubmitting) ? (<Alert severity="success">Your delivery has been confirmed!</Alert>) :
                    (
                        <form onSubmit={handleSubmit} onChange={handleChange} autoComplete="off" noValidate>
                        <FormControl fullWidth sx={{m: 1}} style={{display:'inline-block'}} variant="outlined">
                            <TextField id="productName" name="productName" style={{display:'inline-block'}}  label="Product Name" variant="outlined"  value={values.name}/>
                            <TextField id="productDescription" name="productDescription"  style={{display:'inline-block'}} label="Product Description" variant="outlined" value={values.description} />
                            <TextField id="toContactNumber" label="To Contact Number" variant="outlined"  style={{display:'inline-block'}} name="toContactNumber" value={values.to}/>
                            <TextField id="fromContactNumber" label="From Contact Number" variant="outlined" style={{display:'inline-block'}}  name="fromContactNumber" value={values.from}/>                            
                            <TextField id="quantity" label="Quantity" variant="outlined" style={{display:'inline-block'}}  name="quantity" value={values.from}/>                            
                            <TextField id="toAddress" label="To Address" variant="outlined" style={{display:'inline-block'}}  name="toAddress" value={values.from}/>                            
                            <TextField id="fromAddress" label="From Address" variant="outlined" style={{display:'inline-block'}}  name="fromAddress" value={values.from}/>                            
                            <button type="submit" className="form-btn" style={{fontSize: '18px'}}>
                                Place Order
                            </button>
                        </FormControl>
                        </form>
                    )}

                </div>


            </div>

        </section>
    )
}
