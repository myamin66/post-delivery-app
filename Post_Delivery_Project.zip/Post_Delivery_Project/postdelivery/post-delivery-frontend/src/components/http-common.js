import axios from "axios";
export default axios.create({
    // baseURL:"https://time-table-server.herokuapp.com",
    // baseURL:"https://postdeliveryapp.herokuapp.com",
    baseURL:"http://localhost:8284",
    header:{
        "Content-type":"application/json"
    }
});