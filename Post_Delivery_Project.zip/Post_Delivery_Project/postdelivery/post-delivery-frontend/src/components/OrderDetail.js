import React, { useState, useContext, useEffect } from 'react';
import { Link } from "react-router-dom";
import { DataContext } from "./DataProvider";
import Swal from 'sweetalert2'
import Dataservices from './Dataservices';
import { useParams } from 'react-router-dom/cjs/react-router-dom.min';


export default function OrderDetails() {

    const value = useContext(DataContext);
    const { id } = useParams();
    const orders = value.orders;
    const details = orders.filter((order) => order.id == id)    
    const [order,setOrder] = useState();
    useEffect(() => {
        setOrder(details[0])
    },[])

    return (
        <section>
            <div className="cart">
                <div className="cart-box">
                    <div className="card" key={order && order.id}>          
                        <div className="card-content">
                            <span>Product Name : {order && order.productName}</span> 
                            <br></br>
                            <span>Product Description : {order && order.productDescription}</span>
                            <br></br>
                            <span>To Contact Number : {order && order.toContactNumber}</span>
                            <br></br>                            
                            <span>Quantity : {order && order.quantity}</span>
                            <br></br>
                            <span>To Address : {order && order.toAddress}</span>
                            <br></br>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    )
}
