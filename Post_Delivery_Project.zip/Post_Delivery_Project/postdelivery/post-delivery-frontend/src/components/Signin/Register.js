import React, { useContext, useEffect, useState } from 'react';
import validate from "./Validation";
import FormSuccess from "./FormSuccess";
import { DataContext } from '../DataProvider';
import Dataservices from '../Dataservices';
import FormSignupSuccess from './FormSignupSuccess';
import { Link } from 'react-router-dom';


export default function Register() {
    const [values, setValues] = useState({ name:"",role:"",phone:"",address:"",about:"",email: "", password: "" });
    const value = useContext(DataContext)
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [errors, setErrors] = useState({});
    

    const handleInput = event => {
        setValues({
            ...values,
            [event.target.name]: event.target.value
        });
    };


    const handleSubmit = event => {
        event.preventDefault();
        Dataservices.register({...values,["phone"]:+values.phone}).then(res => {
                setIsSubmitting(true);
                value.setCurrentUser(res.data)
                localStorage.setItem("productUser674",JSON.stringify(res.data))
        }).catch(err => setErrors(validate(values)) )
    }

    return (
        <section>
            { (isSubmitting) ? (<FormSignupSuccess/>) :
                (<div className="form-container">
                    <h2>Register</h2>
                    <form onSubmit={handleSubmit}  onChange={handleInput} autoComplete="off" noValidate>
                        <div className="form-input">
                            <label>Name</label>
                            <input name="name" type="text" value={values.name} />
                        </div>

                        <div className="form-input">
                            <label>Email</label>
                            <input name="email" type="text" value={values.email} />
                        </div>

                        <div className="form-input">
                            <label>Phone</label>
                            <input name="phone" type="text" value={values.phone} />
                        </div>

                        <div className="form-input">
                            <label>Address</label>
                            <input name="address" type="text" value={values.address} />
                        </div>

                        <div className="form-input">
                            <label>About</label>
                            <input name="about" type="text" value={values.about} />
                        </div>

                        <div className="form-input">
                            <label>Password</label>
                            <input name="password" type="password" value={values.password} />
                        </div>

                        <div className="form-input">
                            <label>Role(post/order)</label>
                            <input name="role" type="text" value={values.role} />
                        </div>

                        <button type="submit" className="form-btn">Register</button>
                        <Link to="/login">Login</Link>
                    </form>
                </div>)}
        </section>
    )
}
