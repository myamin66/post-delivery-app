import React, { useContext, useEffect, useState } from 'react';
import validate from "./Validation";
import FormSuccess from "./FormSuccess";
import { DataContext } from '../DataProvider';
import Dataservices from '../Dataservices';
import { Link } from 'react-router-dom';


export default function Login() {
    const [values, setValues] = useState({ email: "", password: "" });
    const value = useContext(DataContext)
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [errors, setErrors] = useState({});

    

    const handleInput = event => {
        setValues({
            ...values,
            [event.target.name]: event.target.value
        });
    };


    const handleSubmit = event => {
        event.preventDefault();
        Dataservices.signin({email:values.email,password:values.password}).then(res => {
                setIsSubmitting(true);
                value.setCurrentUser(res.data)
                localStorage.setItem("productUser674",JSON.stringify(res.data))
        }).catch(err => setErrors(validate(values)) )
    }

    return (
        <section>
            { (isSubmitting) ? (<FormSuccess />) :
                (<div className="form-container">
                    <h2>Login</h2>
                    <form onSubmit={handleSubmit}  onChange={handleInput} autoComplete="off" noValidate>
                        <div className="form-input">
                            <label>Email</label>
                            <input name="email" type="text" value={values.email} />
                        </div>

                        <div className="form-input">
                            <label>Password</label>
                            <input name="password" type="password"value={values.password} />
                        </div>

                        <button type="submit" className="form-btn">Login</button>
                        <Link to="/register">Register</Link>
                    </form>
                </div>)}
        </section>
    )
}
