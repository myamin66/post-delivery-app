import React, {useContext, useEffect} from 'react';
import {Link} from "react-router-dom";
import ShippingIcon from '@material-ui/icons/LocalShipping';
import SupportIcon from '@material-ui/icons/ContactSupport';
import ReturnIcon from '@material-ui/icons/MonetizationOn';
import CancelIcon from '@material-ui/icons/Cancel';
import {DataContext} from "./DataProvider";
import Dataservices from './Dataservices';

export default function Home() {
    const value = useContext(DataContext);
    const styles = {

        largeIcon: {
            width: 30,
            height: 30,
            marginRight: 3
        },
        backgroundImage: {
            width: '500px',
            borderRadius: 0,
            backgroundColor: 'none'
        }

    };

    return (
        <section>
            <div className="landing-box">
                <div>
                    <h1>Everything you need. Delivered right to your door. We ship you happiness.</h1>
                    <p>We are World's fastest delivery system.</p>
                    <div className="row">
                        {
                            value.currentUser && value.currentUser.role=="post" && <Link to="/addDelivery">Post</Link> }{
                            value.currentUser && value.currentUser.role=="order" && <Link to="/addOrder">Order</Link>                                 
                        }
                    </div>
                </div>

                <img src="bg.png" alt="landing-pic"/>
            </div>
            <div className="features">
                <div className="features-card">
                    <p className="features-head"><ShippingIcon style={styles.largeIcon}/>Fast Delivery</p>
                    <p className="features-para">Cash on delivery</p>
                </div>

                <div className="features-card">
                    <p className="features-head"><CancelIcon style={styles.largeIcon}/>Satisfaction</p>
                    <p className="features-para">Customer satisfaction</p>
                </div>

                <div className="features-card">
                    <p className="features-head"><ReturnIcon style={styles.largeIcon}/>Reliable Service</p>
                    <p className="features-para">Safe, Secure and Reliable</p>
                </div>

                <div className="features-card">
                    <p className="features-head"><SupportIcon style={styles.largeIcon}/>Customer Care</p>
                    <p className="features-para">24/7 Customer Care support.</p>
                </div>

            </div>
        </section>
    )
}
