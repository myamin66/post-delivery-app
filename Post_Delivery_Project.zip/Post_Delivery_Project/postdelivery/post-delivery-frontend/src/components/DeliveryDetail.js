import React, { useState, useContext, useEffect } from 'react';
import { Link } from "react-router-dom";
import { DataContext } from "./DataProvider";
import Swal from 'sweetalert2'
import Dataservices from './Dataservices';
import { useParams } from 'react-router-dom/cjs/react-router-dom.min';


export default function DeliveryDetails() {

    const value = useContext(DataContext);
    const { id } = useParams();
    const deliveries = value.deliveries;
    const details = deliveries.filter((delivery) => delivery.id == id)    
    const [delivery,setDelivery] = useState();
    useEffect(() => {
        setDelivery(details[0])
    },[])

    return (
        <section>
            <div className="cart">
                <div className="cart-box">
                    <div className="card" key={delivery && delivery.id}>          
                        <div className="card-content">
                            <span>Product Name : {delivery && delivery.productName}</span> 
                            <br></br>
                            <span>Product Description : {delivery && delivery.productDescription}</span>
                            <br></br>
                            <span>To Contact Number : {delivery && delivery.toContactNumber}</span>
                            <br></br>                            
                            <span>From Contact Number : {delivery && delivery.fromContactNumber}</span>
                            <br></br>
                            <span>Quantity : {delivery && delivery.quantity}</span>
                            <br></br>
                            <span>To Address : {delivery && delivery.toAddress}</span>
                            <br></br>
                            <span>From Address : {delivery && delivery.fromAddress}</span>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    )
}
